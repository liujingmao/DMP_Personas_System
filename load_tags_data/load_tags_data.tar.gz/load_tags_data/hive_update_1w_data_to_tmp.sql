LOAD DATA INPATH '/1w_dws_user_action_tags_map_all.txt' OVERWRITE INTO TABLE `tmp.dws_user_action_tags_map_all_tmp`; 
