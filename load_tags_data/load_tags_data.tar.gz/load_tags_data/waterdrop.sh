#!/bin/sh

/waterdrop-1.5.1/bin/start-waterdrop.sh --master local[*] --deploy-mode client --config /waterdrop-1.5.1/config/batch.conf.template
