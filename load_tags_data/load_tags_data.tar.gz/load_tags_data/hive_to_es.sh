#!/bin/sh

echo "=========把无关容器关闭，省点内存  =============="
cd ../
source ./stop-nginx.sh
source ./stop-redis.sh
source ./stop-clickhouse.sh
echo "=========打开es,spark容器  =============="
source ./es.sh
source ./spark.sh
source ./hive.sh
source ./hbase.sh
cd load_tags_data
echo "=========等待20秒，让容器完全启动,请等待  =============="
sleep 20
echo "=========通过 Spark将Hive数据写入ES==========="
docker cp TagsToESApplication.jar spark-master:/
docker cp TagsToESApplication.sh spark-master:/
docker cp log4j.properties spark-master:/
docker exec -it spark-master /bin/bash -c "sh TagsToESApplication.sh"
docker cp es_show_data.sh es:/usr/share/elasticsearch
docker exec -it es /bin/bash -c "sh es_show_data.sh"
echo "======数据成功写入ES==========="