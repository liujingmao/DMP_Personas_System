#!/bin/sh

echo "=========把无关容器关闭，省点内存  =============="
cd ../
source ./stop-all.sh
echo "==========打开hive容器  =============="
source ./hive.sh
cd load_tags_data
echo "=========等待20秒，让容器完全启动,请等待  =============="
sleep 20
echo "=========上传到人群标签数据 hdfs  =============="
docker cp 1w_dws_user_action_tags_map_all.txt namenode:/
docker exec -it namenode /bin/bash -c "hdfs dfs -put -f /1w_dws_user_action_tags_map_all.txt /1w_dws_user_action_tags_map_all.txt"
echo "=========导入人群标签数据  =============="
docker cp hive_update_1w_data_to_tmp.sql hive-server:/opt
docker cp hive_update_data_to_orc.sql hive-server:/opt
docker cp hive_del_tmp.sql hive-server:/opt
docker exec -it hive-server /bin/bash -c "hive -f hive_update_1w_data_to_tmp.sql"
docker exec -it hive-server /bin/bash -c "hive -f hive_update_data_to_orc.sql"
docker exec -it hive-server /bin/bash -c "hive -f hive_del_tmp.sql"
echo "======打印输出用户标签流水表数据==========="
docker exec -it hive-server /bin/bash -c "hive -e 'select * from dw.dws_user_action_tags_map_all limit 10'"
echo "============数据导入成功==========="
echo "====可以查看Hive表：dw.dws_user_action_tags_map_all======="