#!/bin/sh

echo "=========ch 转换为Bitmap=============="
docker exec -it clickhouse /bin/bash -c "clickhouse-client --query='insert into ch_tags_string_with_bitmap select tag_id,tag_value,bitmapBuild(user_ids) AS user_ids FROM ch_tags_string_with_view'"
docker exec -it clickhouse /bin/bash -c "clickhouse-client --query='select tag_id,tag_value,bitmapToArray(groupBitmapMergeState(user_ids)) from ch_tags_string_with_bitmap group by tag_id,tag_value'"
echo "=========ch 转换为Bitmap成功=============="