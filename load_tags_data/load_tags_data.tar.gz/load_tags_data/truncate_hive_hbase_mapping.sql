CREATE TEMPORARY TABLE IF NOT EXISTS `dwt_user_tags_map_all_template`(
  `user_id` string comment '用户id',
  `user_tags` map<string,string> comment '用户标签聚合' 
)COMMENT '用户标签主题表'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
map keys terminated by ':'
;

insert overwrite table dw.dwt_user_tags_map_all select * from dwt_user_tags_map_all_template;