#!/bin/sh

echo "=========把无关容器关闭，省点内存  =============="
cd ../
source ./stop-es.sh
source ./stop-nginx.sh
source ./stop-redis.sh
echo "=========打开ch,spark容器  =============="
source ./clickhouse.sh
source ./spark.sh
source ./hive.sh
source ./hbase.sh
cd load_tags_data
tar xzvf waterdrop-1.5.1.tar.gz
echo "=========等待20秒，让容器完全启动,请等待  =============="
sleep 20
echo "=========通过waterdrop将hive数据写入ch=============="
docker cp waterdrop-1.5.1 spark-master:/
docker cp waterdrop.sh spark-master:/
docker exec -it spark-master /bin/bash -c "sh waterdrop.sh"
docker exec -it clickhouse /bin/bash -c "clickhouse-client --query='select * from ch_hive_tags_string_map_all'"
echo "=========hive数据成功写入ch=============="