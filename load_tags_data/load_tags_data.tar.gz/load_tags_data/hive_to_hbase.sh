#!/bin/sh

echo "=========把无关容器关闭，省点内存  =============="
cd ../
source ./stop-spark.sh
source ./stop-es.sh
source ./stop-clickhouse.sh
source ./stop-nginx.sh
source ./stop-redis.sh
echo "=========打开hive,hbase容器  =============="
source ./hive.sh
source ./hbase.sh
cd load_tags_data
echo "=========等待20秒，让容器完全启动,请等待  =============="
sleep 20
echo "=========清空 hbase user_tags_map_all============="
docker cp hbase_shell_truncate.txt hbase-master:/
docker exec -it hbase-master /bin/bash -c "hbase shell hbase_shell_truncate.txt"
echo "================导入数据========================="
docker cp hive_insert_table_dwt_user_tags_map_all.sql hive-server:/opt
docker exec -it hive-server /bin/bash -c "hive -f hive_insert_table_dwt_user_tags_map_all.sql"
docker cp show_dwt_user_tags_map_all.sql hive-server:/opt
echo "======打印输出用户标签主题表数据==========="
docker exec -it hive-server /bin/bash -c "hive -e 'select * from dw.dwt_user_tags_map_all limit 10'"
echo "============数据导入成功==========="
echo "====可以查看Hive表：dw.dwt_user_tags_map_all======="
echo "====可以查看Hbase表：user_tags_map_all======="
