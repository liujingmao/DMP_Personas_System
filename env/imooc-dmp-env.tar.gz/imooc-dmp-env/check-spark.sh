#!/bin/sh

echo "=========检查 spark 启动状态=============="
docker-compose ps spark-master spark-worker-1 spark-worker-2 spark-worker-3