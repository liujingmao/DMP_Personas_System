show databases;
use hive;
show tables;
show grants for hive;