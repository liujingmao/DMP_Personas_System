#!/bin/sh


echo "=========停止 clickhouse =============="
docker-compose stop clickhouse 
echo "=========移除 clickhouse 容器=============="
docker rm clickhouse 
