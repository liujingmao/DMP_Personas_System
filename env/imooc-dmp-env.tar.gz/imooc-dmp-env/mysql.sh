#!/bin/sh

echo "=========启动 mysql =============="
docker-compose up -d mysql

source ./check-mysql.sh