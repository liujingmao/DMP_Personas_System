#!/bin/sh

docker cp init-mysql.sql mysql:/
docker cp hive-metastore.sql mysql:/
docker exec -it mysql bash -c "mysql -uroot -p123456 < /init-mysql.sql"

echo "=============打印输出 hive数据库及表，hive用户权限================="
source ./check-init-mysql.sh
echo "=============mysql初始化完成================="
