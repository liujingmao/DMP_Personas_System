#!/bin/sh

echo "=========检查 es 启动状态=============="
docker-compose ps es