!table
select * from "phoenix_test";
select * from "hbase_test";