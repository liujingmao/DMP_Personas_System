#!/bin/sh

echo "=========清理环境=============="
source ./clean.sh
echo "=========环境搭建开始=============="
echo -e "\n"
echo "=========建立网络 imooc_dmp_network =============="
docker network create --driver bridge --subnet 172.23.0.0/24 --gateway 172.23.0.1 imooc_dmp_network
echo "=========执行 Dockerfile-hbase =============="
docker build -f Dockerfile-hbase -t bde2020/hbase-regionserver-imooc-dmp:1.0.0-hbase1.2.6 .
echo "=========执行 Dockerfile-hive =============="
docker build -f Dockerfile-hive -t bde2020/hive-imooc-dmp:2.3.2-postgresql-metastore .
echo "=========执行 Dockerfile-spark-master =============="
docker build -f Dockerfile-spark-master -t spark-master-imooc-dmp:2.3.0-hadoop2.7 .
echo "=========执行 Dockerfile-spark-worker =============="
docker build -f Dockerfile-spark-worker -t spark-worker-imooc-dmp:2.3.0-hadoop2.7 .
echo "=========初始化 mysql =============="
sh mysql.sh
echo "### 等待20秒,让mysql完全启动 不要终止程序 安装还没完成 ####"
echo "### 等待20秒,让mysql完全启动 不要终止程序 安装还没完成 ####"
echo "### 等待20秒,让mysql完全启动 不要终止程序 安装还没完成 ####"
echo "### 等待20秒,让mysql完全启动 不要终止程序 安装还没完成 ####"
echo "### 等待20秒,让mysql完全启动 不要终止程序 安装还没完成 ####"
echo "### 等待20秒,让mysql完全启动 不要终止程序 安装还没完成 ####"
echo "### 等待20秒,让mysql完全启动 不要终止程序 安装还没完成 ####"
echo "### 等待20秒,让mysql完全启动 不要终止程序 安装还没完成 ####"
echo "### 等待20秒,让mysql完全启动 不要终止程序 安装还没完成 ####"
sleep 20
sh init-mysql.sh
echo "=========关闭所有容器 =============="
sh stop-all.sh
echo -e "\n"
echo "=========搭建完成，执行以下脚本启动组件=============="
echo "=========hdfs组: sh hdfs.sh=============="
echo "=========yarn组: sh yarn.sh=============="
echo "=========hive组: sh hive.sh=============="
echo "=========hbase组: sh hbase.sh=============="
echo "=========spark组: sh spark.sh=============="
echo "=========nginx组: sh nginx.sh=============="
echo "=========es组: sh es.sh=============="
echo "=========clickhouse组: sh clickhouse.sh=============="
echo "=========mysql组: sh mysql.sh=============="
echo "=========redis组: sh redis.sh=============="


