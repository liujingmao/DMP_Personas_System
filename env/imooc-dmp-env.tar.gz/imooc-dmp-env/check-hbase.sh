#!/bin/sh

echo "=========检查 hbase 启动状态 =============="
docker-compose ps zoo1 zoo2 zoo3 hbase-master hbase-regionserver-1 hbase-regionserver-2 hbase-regionserver-3 phoenix