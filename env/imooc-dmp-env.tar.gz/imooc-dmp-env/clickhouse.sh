#!/bin/sh

echo "=========启动 clickhouse =============="
docker-compose up -d clickhouse

source ./check-clickhouse.sh
