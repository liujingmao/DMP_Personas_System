#!/bin/sh

echo "==========关闭无关组件，省点内存================="
source ./stop-all.sh
echo "=========打开clickhouse容器  =============="
source ./clickhouse.sh
echo "=========睡眠20秒,等ch完全启动,请等待 =============="
sleep 20
echo "========创建 clickhouse 表结构=============="
docker cp ch_create_table.sql clickhouse:/
docker exec -it clickhouse /bin/bash -c "clickhouse-client --multiquery < ch_create_table.sql"
echo "========打印输出clickhouse表=============="
docker exec -it clickhouse /bin/bash -c "clickhouse-client --query='show tables'"
echo "========创建clickhouse表结构成功=============="
