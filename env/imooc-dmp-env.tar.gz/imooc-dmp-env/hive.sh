#!/bin/sh

source ./hdfs.sh
source ./mysql.sh

echo "=========启动 hive =============="
docker-compose up -d hive-metastore
docker-compose up -d hive-server

source ./check-hive.sh