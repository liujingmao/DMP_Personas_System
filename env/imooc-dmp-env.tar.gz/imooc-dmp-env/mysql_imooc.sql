/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50733
 Source Host           : localhost:3306
 Source Schema         : imooc

 Target Server Type    : MySQL
 Target Server Version : 50733
 File Encoding         : 65001

 Date: 13/03/2022 22:27:27
*/

SET NAMES 'utf8';
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS imooc CHARACTER SET utf8 COLLATE utf8_general_ci;

USE imooc;

-- ----------------------------
-- Table structure for crowds
-- ----------------------------
DROP TABLE IF EXISTS `crowds`;
CREATE TABLE `crowds`  (
  `crowd_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `crowd_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '人群名称',
  `crowd_type_cn` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '人群属性',
  `crowd_count` int(11) UNSIGNED NOT NULL COMMENT '人群数量',
  `expire` int(11) NOT NULL COMMENT '有效天数 -1是永久',
  `crowd_group` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '人群所属组 第一层级',
  `crowd_group_second` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '人群所属组 第二层级',
  `ch_id` int(11) UNSIGNED NOT NULL COMMENT 'ch表id',
  `tags` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '筛选条件(标签)',
  PRIMARY KEY (`crowd_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '人群表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of crowds
-- ----------------------------
INSERT INTO `crowds` VALUES (1, '30天内购买化妆品至少3次且年龄介于20-30女性人群', '类目人群	', 870059, 30, '营销人群', '促销活动', 1, '3,5,22');
INSERT INTO `crowds` VALUES (2, '坚果食品大批量采购人群', '优质人群', 837400, 30, '营销人群', '促销活动', 1, '3,5,23');
INSERT INTO `crowds` VALUES (3, '化妆品高频消费人群', '类目人群', 581889, 30, '营销人群', '促销活动', 1, '3,5,24');
INSERT INTO `crowds` VALUES (4, '7天内浏览过化妆品类目人群', '类目人群', 457234, 30, '营销人群', '单品推广', 1, '3,5,25');
INSERT INTO `crowds` VALUES (5, '30天内购买过雅兰黛丝品牌的人群', '品牌人群', 514020, 30, '营销人群', '单品推广', 1, '3,5,26');
INSERT INTO `crowds` VALUES (6, '18-24岁少女且常住一线城市人群', '人口属性', 966522, 30, '营销人群', '单品推广', 1, '3,5,27');
INSERT INTO `crowds` VALUES (7, '化妆品高消费金额人群', '优质人群', 316493, 30, '营销人群', '促销活动', 1, '3,5,28');
INSERT INTO `crowds` VALUES (8, '领用过618购物津贴并当天使用人群', '节日人群', 604589, 30, '营销人群', '促销活动', 1, '3,5,29');
INSERT INTO `crowds` VALUES (9, '年货节有高频浏览行为但未成交人群', '节日人群', 30363, 30, '营销人群', '促销活动', 1, '3,5,30');
INSERT INTO `crowds` VALUES (10, '年货节购买了预售商品人群', '节日人群', 143806, 30, '营销人群', '促销活动', 1, '3,5,31');

-- ----------------------------
-- Table structure for tags
-- ----------------------------
DROP TABLE IF EXISTS `tags`;
CREATE TABLE `tags`  (
  `tag_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id',
  `tag_level` tinyint(2) NOT NULL COMMENT '标签一级分组id',
  `tag_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '标签值',
  `tag_level_second` tinyint(2) NOT NULL COMMENT '标签二级分组id',
  `tag_id_string` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '标签id',
  `tag_name_cn` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '标签名',
  `tag_level_cn` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '标签一级分组名称',
  `tag_level_second_cn` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '标签二级分组名称',
  `tag_value_type_cn` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '标签值类型cn',
  `tag_value_type` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '标签值类型en',
  `tag_expire` int(11) NOT NULL DEFAULT 30 COMMENT '标签有效天数 -1永久',
  `tag_type_cn` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '标签类型',
  `tag_type` tinyint(2) UNSIGNED NOT NULL COMMENT '标签类型id 1基础标签 2复合标签',
  `tag_status` tinyint(2) NOT NULL DEFAULT 1 COMMENT '标签状态 1 正常 -1 下架',
  PRIMARY KEY (`tag_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 130 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tags
-- ----------------------------
INSERT INTO `tags` VALUES (17, 2, '充值土豪', 1, 'CONSUME_02_33', '用户级别', '消费标签', '消费等级', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (18, 2, '会员', 1, 'CONSUME_02_32', '用户级别', '消费标签', '消费等级', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (19, 2, '新用户', 1, 'CONSUME_02_31', '用户级别', '消费标签', '消费等级', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (20, 2, '一般保持用户', 1, 'CONSUME_04_20', 'rfm客户模型', '消费标签', '消费等级', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (21, 2, '重要价值用户', 1, 'CONSUME_04_21', 'rfm客户模型', '消费标签', '消费等级', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (22, 2, '重要保持用户', 1, 'CONSUME_04_22', 'rfm客户模型', '消费标签', '消费等级', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (23, 2, '一般价值用户', 1, 'CONSUME_04_23', 'rfm客户模型', '消费标签', '消费等级', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (24, 2, '高消费用户', 2, 'CONSUME_02_24', '消费水平', '消费标签', '消费等级', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (25, 2, '普通消费用户', 2, 'CONSUME_02_25', '消费水平', '消费标签', '消费等级', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (26, 2, '低消费用户', 2, 'CONSUME_02_26', '消费水平', '消费标签', '消费等级', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (27, 1, '男性', 1, 'PROFILE_01_27', '性别', '属性标签', '自然属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (28, 1, '女性', 1, 'PROFILE_01_28', '性别', '属性标签', '自然属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (29, 2, '流失用户', 1, 'CONSUME_02_29', '用户忠诚度', '消费标签', '消费等级', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (30, 2, '复购用户', 1, 'CONSUME_02_30', '用户忠诚度', '消费标签', '消费等级', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (31, 3, '偏好下午下单', 2, 'ACTION_02_31', '下单时间段', '行为标签', '下单行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (32, 3, '偏好晚上下单', 2, 'ACTION_02_32', '下单时间段', '行为标签', '下单行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (33, 3, '偏好凌晨下单', 2, 'ACTION_02_33', '下单时间段', '行为标签', '下单行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (34, 3, '偏好上午下单', 2, 'ACTION_02_34', '下单时间段', '行为标签', '下单行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (35, 3, '不确定偏好下单时间', 2, 'ACTION_02_35', '下单时间段', '行为标签', '下单行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (52, 1, '20岁以下', 1, 'PROFILE_01_52', '年龄段', '属性标签', '自然属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (53, 1, '20-25岁', 1, 'PROFILE_01_53', '年龄段', '属性标签', '自然属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (54, 1, '25-30岁', 1, 'PROFILE_01_54', '年龄段', '属性标签', '自然属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (55, 1, '30-40岁', 1, 'PROFILE_01_55', '年龄段', '属性标签', '自然属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (56, 1, '40-50岁', 1, 'PROFILE_01_56', '年龄段', '属性标签', '自然属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (57, 1, '50岁以上', 1, 'PROFILE_01_57', '年龄段', '属性标签', '自然属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (58, 1, '学生', 2, 'PROFILE_01_58', '职业类别', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (59, 1, '无业', 2, 'PROFILE_01_59', '职业类别', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (60, 1, '军人', 2, 'PROFILE_01_60', '职业类别', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (61, 1, '事业单位', 2, 'PROFILE_01_61', '职业类别', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (62, 1, '服务业', 2, 'PROFILE_01_62', '职业类别', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (63, 1, '私人企业', 2, 'PROFILE_01_63', '职业类别', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (64, 1, '家庭主妇', 2, 'PROFILE_01_64', '职业类别', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (65, 1, '工厂', 2, 'PROFILE_01_65', '职业类别', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (66, 1, '外资企业', 2, 'PROFILE_01_66', '职业类别', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (67, 1, '高管', 2, 'PROFILE_01_67', '职业级别', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (68, 1, '老板', 2, 'PROFILE_01_68', '职业级别', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (69, 1, '普通员工', 2, 'PROFILE_01_69', '职业级别', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (70, 1, '中层管理人员', 2, 'PROFILE_01_70', '职业级别', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (71, 1, '技术研发人员', 2, 'PROFILE_01_71', '职业级别', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (72, 1, '10万以下', 2, 'PROFILE_01_72', '收入水平', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (73, 1, '10-20万', 2, 'PROFILE_01_73', '收入水平', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (74, 1, '20-30万', 2, 'PROFILE_01_74', '收入水平', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (75, 1, '30-40万', 2, 'PROFILE_01_75', '收入水平', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (76, 1, '40-50万', 2, 'PROFILE_01_76', '收入水平', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (77, 1, '50-100万', 2, 'PROFILE_01_77', '收入水平', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (78, 1, '100万以上', 3, 'PROFILE_01_78', '收入水平', '属性标签', '社会属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (79, 3, '偏好下午浏览', 3, 'ACTION_03_79', '浏览时间段', '行为标签', '浏览行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (80, 3, '偏好晚上浏览', 3, 'ACTION_03_80', '浏览时间段', '行为标签', '浏览行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (81, 3, '偏好凌晨浏览', 3, 'ACTION_03_81', '浏览时间段', '行为标签', '浏览行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (82, 3, '偏好上午浏览', 3, 'ACTION_03_82', '浏览时间段', '行为标签', '浏览行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (83, 3, '不确定偏好浏览时间', 3, 'ACTION_03_83', '浏览时间段', '行为标签', '浏览行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (84, 2, '0-20元', 1, 'CONSUME_02_84', '近7天食品类消费金额', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (85, 2, '20-50元', 1, 'CONSUME_02_85', '近7天食品类消费金额', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (86, 2, '50-100元', 1, 'CONSUME_02_86', '近7天食品类消费金额', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (87, 2, '100-200元', 1, 'CONSUME_02_87', '近7天食品类消费金额', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (88, 2, '200-300元', 1, 'CONSUME_02_88', '近7天食品类消费金额', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (89, 2, '300元以上', 1, 'CONSUME_02_89', '近7天食品类消费金额', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (90, 2, '0-100元', 1, 'CONSUME_02_90', '近30天食品类消费金额', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (91, 2, '100-200元', 1, 'CONSUME_02_91', '近30天食品类消费金额', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (92, 2, '200-300元', 1, 'CONSUME_02_92', '近30天食品类消费金额', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (93, 2, '300-500元', 1, 'CONSUME_02_93', '近30天食品类消费金额', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (94, 2, '500元以上', 1, 'CONSUME_02_94', '近30天食品类消费金额', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (95, 2, '0-10天', 1, 'CONSUME_02_95', '最近一次消费距今时间', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (96, 2, '10-20天', 1, 'CONSUME_02_96', '最近一次消费距今时间', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (97, 2, '20-30天', 1, 'CONSUME_02_97', '最近一次消费距今时间', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (98, 2, '30天以上', 1, 'CONSUME_02_98', '最近一次消费距今时间', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (99, 3, '化妆品', 2, 'ACTION_03_99', '收藏最多的品类', '行为标签', '收藏行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (100, 3, '电子产品', 2, 'ACTION_03_100', '收藏最多的品类', '行为标签', '收藏行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (101, 3, '服饰', 2, 'ACTION_03_101', '收藏最多的品类', '行为标签', '收藏行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (102, 3, '食品', 2, 'ACTION_03_102', '收藏最多的品类', '行为标签', '收藏行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (103, 3, '母婴', 2, 'ACTION_03_103', '收藏最多的品类', '行为标签', '收藏行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (104, 3, '化妆品', 3, 'ACTION_03_104', '购买最多的品类', '行为标签', '下单行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (105, 3, '电子产品', 3, 'ACTION_03_105', '购买最多的品类', '行为标签', '下单行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (106, 3, '服饰', 3, 'ACTION_03_106', '购买最多的品类', '行为标签', '下单行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (107, 3, '食品', 3, 'ACTION_03_107', '购买最多的品类', '行为标签', '下单行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (108, 3, '母婴', 3, 'ACTION_03_108', '购买最多的品类', '行为标签', '下单行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (109, 3, '化妆品', 4, 'ACTION_03_109', '搜索最多的品类', '行为标签', '搜索行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (110, 3, '电子产品', 4, 'ACTION_03_110', '搜索最多的品类', '行为标签', '搜索行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (111, 3, '服饰', 4, 'ACTION_03_111', '搜索最多的品类', '行为标签', '搜索行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (112, 3, '食品', 4, 'ACTION_03_112', '搜索最多的品类', '行为标签', '搜索行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (113, 3, '母婴', 4, 'ACTION_03_113', '搜索最多的品类', '行为标签', '搜索行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (114, 2, '化妆品', 3, 'ACTION_03_114', '复购最多的品类', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (115, 2, '电子产品', 3, 'ACTION_03_115', '复购最多的品类', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (116, 2, '服饰', 3, 'ACTION_03_116', '复购最多的品类', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (117, 2, '食品', 3, 'ACTION_03_117', '复购最多的品类', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (118, 2, '母婴', 3, 'ACTION_03_118', '复购最多的品类', '消费标签', '消费统计', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (119, 3, '化妆品', 1, 'ACTION_03_119', '近7天浏览最多的品类', '行为标签', '浏览行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (120, 3, '电子产品', 1, 'ACTION_03_120', '近7天浏览最多的品类', '行为标签', '浏览行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (121, 3, '服饰', 1, 'ACTION_03_121', '近7天浏览最多的品类', '行为标签', '浏览行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (122, 3, '食品', 1, 'ACTION_03_122', '近7天浏览最多的品类', '行为标签', '浏览行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (123, 3, '母婴', 1, 'ACTION_03_123', '近7天浏览最多的品类', '行为标签', '浏览行为', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (124, 1, '高价值科技产品发烧友', 3, 'PROFILE_03_124', '科技产品发烧友', '属性标签', '消费属性', '文本型', 'string', 30, '复合标签', 2, 1);
INSERT INTO `tags` VALUES (125, 1, '极度敏感', 3, 'PROFILE_03_125', '价格敏感度', '属性标签', '消费属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (126, 1, '较敏感', 3, 'PROFILE_03_126', '价格敏感度', '属性标签', '消费属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (127, 1, '一般敏感', 3, 'PROFILE_03_127', '价格敏感度', '属性标签', '消费属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (128, 1, '较不敏感', 3, 'PROFILE_03_128', '价格敏感度', '属性标签', '消费属性', '文本型', 'string', 30, '基础标签', 1, 1);
INSERT INTO `tags` VALUES (129, 1, '极度不敏感', 3, 'PROFILE_03_129', '价格敏感度', '属性标签', '消费属性', '文本型', 'string', 30, '基础标签', 1, 1);

-- ----------------------------
-- Table structure for tags_type
-- ----------------------------
DROP TABLE IF EXISTS `tags_type`;
CREATE TABLE `tags_type`  (
  `type_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id',
  `type_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '标签类型名称',
  `type_parent_id` int(11) UNSIGNED NOT NULL COMMENT '父id',
  `type_group` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '标签类型所属组',
  PRIMARY KEY (`type_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 24 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '标签类型表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tags_type
-- ----------------------------
INSERT INTO `tags_type` VALUES (1, '属性型标签', 0, 'type');
INSERT INTO `tags_type` VALUES (2, '自然属性', 1, 'type');
INSERT INTO `tags_type` VALUES (3, '消费属性', 1, 'type');
INSERT INTO `tags_type` VALUES (4, '社会属性', 1, 'type');
INSERT INTO `tags_type` VALUES (5, '消费型标签', 0, 'type');
INSERT INTO `tags_type` VALUES (6, '消费等级', 5, 'type');
INSERT INTO `tags_type` VALUES (7, '消费统计', 5, 'type');
INSERT INTO `tags_type` VALUES (8, '消费价格', 5, 'type');
INSERT INTO `tags_type` VALUES (9, '行为型标签', 0, 'type');
INSERT INTO `tags_type` VALUES (10, '停留时长', 9, 'type');
INSERT INTO `tags_type` VALUES (11, '加购行为', 9, 'type');
INSERT INTO `tags_type` VALUES (12, '收藏行为', 9, 'type');
INSERT INTO `tags_type` VALUES (13, '下单行为', 9, 'type');
INSERT INTO `tags_type` VALUES (14, '评论行为', 9, 'type');
INSERT INTO `tags_type` VALUES (15, '退货行为', 9, 'type');
INSERT INTO `tags_type` VALUES (16, '浏览行为', 9, 'type');
INSERT INTO `tags_type` VALUES (17, '关键字搜索行为', 9, 'type');
INSERT INTO `tags_type` VALUES (18, '预测型标签', 0, 'type');
INSERT INTO `tags_type` VALUES (19, '购物偏好', 18, 'type');
INSERT INTO `tags_type` VALUES (20, '基础标签', 0, 'group');
INSERT INTO `tags_type` VALUES (21, '复合标签', 0, 'group');
INSERT INTO `tags_type` VALUES (22, '规则匹配', 0, 'rule');
INSERT INTO `tags_type` VALUES (23, '统计', 0, 'rule');

SET FOREIGN_KEY_CHECKS = 1;
