#!/bin/sh

echo "=========停止组件============="
docker-compose down
echo "=========删除数据============="
rm -rf ./data
echo "=========删除自定义镜像============="
customize_images=`docker images | grep 'imooc' | awk '{print $3}'`
echo $customize_images
for each in $customize_images
    do
        echo "删除镜像id："$each
        docker rmi $each
    done
echo "=========删除网络============="
docker network remove imooc_dmp_network