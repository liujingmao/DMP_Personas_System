#!/bin/sh


echo "=========检查 redis 启动状态=============="
docker-compose ps redis