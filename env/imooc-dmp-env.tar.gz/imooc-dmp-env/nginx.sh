#!/bin/sh

echo "=========启动 nginx =============="
docker-compose up -d nginx

source ./check-nginx.sh