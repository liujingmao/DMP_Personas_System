#!/bin/sh

curl -XGET "http://127.0.0.1:9200/imooc/_mapping"