#!/bin/sh


echo "=========检查 hdfs-yarn 启动状态=============="
docker-compose ps namenode datanode1 datanode2 datanode3 resourcemanager nodemanager1 nodemanager2 nodemanager3 historyserver