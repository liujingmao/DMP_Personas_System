echo "=========查看 hbase 数据=============="
docker cp hbase-command.txt hbase-master:/
docker exec -it hbase-master /bin/bash -c "hbase shell /hbase-command.txt"
