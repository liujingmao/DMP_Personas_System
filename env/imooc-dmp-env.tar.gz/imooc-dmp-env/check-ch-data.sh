echo "=========查看 ch_hive_tags_string_map_all 数据=============="
docker exec -it clickhouse /bin/bash -c "clickhouse-client --query='select * from ch_hive_tags_string_map_all limit 10'"
echo "=========查看 ch_tags_string_with_bitmap 数据=============="
docker exec -it clickhouse /bin/bash -c "clickhouse-client --query='select * from ch_tags_string_with_bitmap limit 10'"