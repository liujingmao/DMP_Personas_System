show databases;
use dwd;
show tables;
use dw;
show tables;