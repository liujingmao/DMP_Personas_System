#!/bin/sh

echo "==========关闭无关组件，省点内存================="
source ./stop-spark.sh
source ./stop-es.sh
source ./stop-nginx.sh
source ./stop-redis.sh
source ./stop-clickhouse.sh
echo "======打开 hive,hbase 组件========="
source ./hive.sh
source ./hbase.sh
echo "=========等待20秒，让容器完全启动,请等待  =============="
sleep 20
echo "======建Hbase表结构========="
docker cp create_hbase_table.txt hbase-master:/
docker exec -it hbase-master /bin/bash -c "hbase shell create_hbase_table.txt"
echo "======建Phoenix表结构========="
docker cp create_phoenix_table.sql phoenix:/
docker exec -it phoenix /bin/bash -c "/opt/phoenix-server/bin/sqlline.py zoo1:2181 /create_phoenix_table.sql"
echo "======打印输出hbase表(8张表)========="
docker cp check_hbase_table.txt hbase-master:/
docker exec -it hbase-master /bin/bash -c "hbase shell check_hbase_table.txt"
echo "======打印输出phoenix表(8张表)========="
docker cp check_phoenix_table.sql phoenix:/
docker exec -it phoenix /bin/bash -c "/opt/phoenix-server/bin/sqlline.py zoo1:2181 /check_phoenix_table.sql"
echo "======建mysql表结构========="
docker cp mysql_imooc.sql mysql:/
docker exec -it mysql bash -c "mysql -uroot -p123456 < /mysql_imooc.sql"
echo "======打印输出mysql表==========="
docker cp check-imooc-mysql.sql mysql:/
docker exec -it mysql bash -c "mysql -uroot -p123456 < /check-imooc-mysql.sql"
echo "======建Hive表结构========="
docker cp hive_create_table.sql hive-server:/opt
docker exec -it hive-server /bin/bash -c "hive -f hive_create_table.sql"
echo "======打印输出Hive数仓的数据库(3个库)==========="
docker exec -it hive-server /bin/bash -c "hive -e 'show databases'"
echo "======打印输出Hive数仓的表(13张表)==========="
docker cp show_hive_tables.sql hive-server:/opt
docker exec -it hive-server /bin/bash -c "hive -f show_hive_tables.sql"
echo "======导入Hive数仓数据==========="
docker cp dataSets namenode:/
docker exec -it namenode /bin/bash -c "hdfs dfs -put -f /dataSets /dataSets"
docker cp hive_load_data_to_tmp.sql hive-server:/opt
docker cp hive_insert_into_orc.sql hive-server:/opt
docker cp hive_insert_table_dwt_user_tags_map_all.sql hive-server:/opt
docker cp hive_truncate_tmp.sql hive-server:/opt
docker cp hive_user_action_map.sql hive-server:/opt
docker exec -it hive-server /bin/bash -c "hive -f hive_load_data_to_tmp.sql"
docker exec -it hive-server /bin/bash -c "hive -f hive_insert_into_orc.sql"
docker exec -it hive-server /bin/bash -c "hive -f hive_truncate_tmp.sql"
docker exec -it hive-server /bin/bash -c "hive -f hive_user_action_map.sql"
echo "======打印输出用户维度表数据==========="
docker exec -it hive-server /bin/bash -c "hive -e 'select * from dwd.dim_user limit 10'"
echo "======打印输出订单维度表数据==========="
docker exec -it hive-server /bin/bash -c "hive -e 'select * from dwd.dim_order limit 10'"
echo "======打印输出产品维度表数据==========="
docker exec -it hive-server /bin/bash -c "hive -e 'select * from dwd.dim_product limit 10'"
echo "======打印输出标签维度表数据==========="
docker exec -it hive-server /bin/bash -c "hive -e 'select * from dwd.dim_tags limit 10'"
echo "======打印输出用户行为维度表数据==========="
docker exec -it hive-server /bin/bash -c "hive -e 'select * from dwd.dim_user_action limit 10'"
echo "======打印输出评论事实表数据==========="
docker exec -it hive-server /bin/bash -c "hive -e 'select * from dw.fact_goods_comments limit 10'"
echo "======打印输出订单明细事实表数据==========="
docker exec -it hive-server /bin/bash -c "hive -e 'select * from dw.fact_order_details limit 10'"
echo "======打印输出行为事实表数据==========="
docker exec -it hive-server /bin/bash -c "hive -e 'select * from dw.fact_user_actions limit 10'"
echo "======打印输出订单维度表数据==========="
docker exec -it hive-server /bin/bash -c "hive -e 'select * from dwd.dim_order limit 10'"
echo "======打印输出用户行为标签聚合表数据==========="
docker exec -it hive-server /bin/bash -c "hive -e 'select * from dw.dws_user_action_tags_map_count_all limit 10'"
echo "======Hive数仓导入成功==========="