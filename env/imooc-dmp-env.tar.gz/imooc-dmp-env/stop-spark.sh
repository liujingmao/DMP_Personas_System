#!/bin/sh

echo "=========停止 spark =============="
docker-compose stop spark-master
docker-compose stop spark-worker-1
docker-compose stop spark-worker-2
docker-compose stop spark-worker-3
echo "=========移除 spark 容器=============="
docker rm spark-master
docker rm spark-worker-1
docker rm spark-worker-2
docker rm spark-worker-3