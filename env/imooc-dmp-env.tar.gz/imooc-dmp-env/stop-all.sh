#!/bin/sh

echo "=========停止所有容器 =============="
docker-compose down