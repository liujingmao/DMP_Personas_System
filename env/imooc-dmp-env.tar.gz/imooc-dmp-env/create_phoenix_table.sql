create table if not exists "phoenix_test"("id" varchar primary key,"info"."name" varchar);
upsert into "phoenix_test"("id","info"."name") values('Imooc-1','Phoenix-1');
upsert into "phoenix_test"("id","info"."name") values('Imooc-2','Phoenix-2');
create table if not exists "user_tags_map_all"("user_id" varchar primary key,"tags" varchar);
create table if not exists "hbase_test"("id" varchar primary key,"info"."name" varchar);
upsert into "hbase_test"("id","info"."name") values('Imooc-1','Hbase-1');
upsert into "hbase_test"("id","info"."name") values('Imooc-2','Hbase-2');