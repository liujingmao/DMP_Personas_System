CREATE TABLE if not exists ch_test (`name` String) ENGINE = TinyLog;
insert into ch_test values('imooc-ch-1');
insert into ch_test values('imooc-ch-2');

create table if not exists ch_tags_string_with_bitmap (
    tag_id String comment '标签id',  
    tag_value String comment '标签值(字符型)',  
    user_ids AggregateFunction(groupBitmap,UInt64) comment 'Bitmap存储用户集合'
)ENGINE = AggregatingMergeTree() ORDER BY (tag_id);

create table if not exists ch_hive_tags_string_map_all (
    user_id UInt64,
    tag_id String comment '标签id',
    tag_value String comment '标签值(字符型)'
)ENGINE = AggregatingMergeTree() ORDER BY user_id;


CREATE MATERIALIZED VIEW if not exists ch_tags_string_with_view (
    tag_id String , 
    tag_value String ,  
    user_ids Array(UInt64)
)ENGINE = AggregatingMergeTree() 
ORDER BY (tag_id) 
POPULATE 
AS SELECT tag_id,tag_value,groupArray(user_id) AS user_ids 
FROM ch_hive_tags_string_map_all 
GROUP BY tag_id,tag_value
