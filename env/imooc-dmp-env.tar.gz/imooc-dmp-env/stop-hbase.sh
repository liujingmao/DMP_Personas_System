#!/bin/sh

echo "=========停止 hbase =============="
docker-compose stop hbase-master
docker-compose stop hbase-regionserver-1
docker-compose stop hbase-regionserver-2
docker-compose stop hbase-regionserver-3
docker-compose stop phoenix
echo "=========移除 hbase 容器=============="
docker rm hbase-master
docker rm hbase-regionserver-1
docker rm hbase-regionserver-2
docker rm hbase-regionserver-3
docker rm phoenix