#!/bin/sh

echo "=========启动 redis =============="
docker-compose up -d redis

source ./check-redis.sh