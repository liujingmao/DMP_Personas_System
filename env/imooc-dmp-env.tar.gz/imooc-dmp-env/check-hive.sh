#!/bin/sh

echo "=========检查 hive 启动状态 =============="
docker-compose ps hive-metastore hive-server mysql