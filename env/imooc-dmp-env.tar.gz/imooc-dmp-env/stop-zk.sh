#!/bin/sh


echo "=========停止 zookeeper =============="
docker-compose stop zoo1 
docker-compose stop zoo2
docker-compose stop zoo3
echo "=========移除 zookeeper 容器=============="
docker rm zoo1 
docker rm zoo2
docker rm zoo3