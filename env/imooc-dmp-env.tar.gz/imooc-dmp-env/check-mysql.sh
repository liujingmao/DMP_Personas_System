#!/bin/sh


echo "=========检查 mysql 启动状态=============="
docker-compose ps mysql