
create database hive;
grant all on hive.* to hive@"%" Identified by '123456';
flush privileges;
use hive;
source /hive-metastore.sql;