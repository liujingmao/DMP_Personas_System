#!/bin/sh

echo "=========检查 zookeeper 启动状态=============="
docker-compose ps zoo1 zoo2 zoo3