#!/bin/sh

echo "=========启动 es =============="
docker-compose up -d es

source ./check-es.sh