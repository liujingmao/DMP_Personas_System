#!/bin/sh

echo "=========停止 hive =============="
docker-compose stop hive-metastore
docker-compose stop hive-server
echo "=========移除 hive 容器=============="
docker rm hive-metastore
docker rm hive-server
