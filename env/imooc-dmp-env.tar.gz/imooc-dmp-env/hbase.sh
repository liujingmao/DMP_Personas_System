#!/bin/sh

source ./hdfs.sh
source ./zk.sh

echo "=========启动 hbase =============="
docker-compose up -d hbase-master
docker-compose up -d hbase-regionserver-1
docker-compose up -d hbase-regionserver-2
docker-compose up -d hbase-regionserver-3
docker-compose up -d phoenix

source ./check-hbase.sh