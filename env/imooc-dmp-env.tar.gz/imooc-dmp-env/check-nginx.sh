#!/bin/sh


echo "=========检查 nginx 启动状态=============="
docker-compose ps nginx