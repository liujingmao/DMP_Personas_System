#!/bin/sh

echo "==========关闭无关组件，省点内存================="
source ./stop-all.sh
echo "=========打开es容器  =============="
source ./es.sh
echo "=========睡眠20秒,等es完全启动,请等待 =============="
sleep 20
echo "=========导入ES Mapping=============="
docker cp es_create_index.sh es:/usr/share/elasticsearch
docker exec -it es /bin/bash -c "bash es_create_index.sh"
echo "=========打印输出 ES Mapping=============="
docker cp es_show_index.sh es:/usr/share/elasticsearch
docker exec -it es /bin/bash -c "bash es_show_index.sh"
echo -e "\n"
echo "======ES Mapping导入成功==========="