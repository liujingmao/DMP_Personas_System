#!/bin/sh

echo "=========停止 yarn =============="
docker-compose stop resourcemanager
docker-compose stop nodemanager1
docker-compose stop nodemanager2
docker-compose stop nodemanager3
docker-compose stop historyserver
echo "=========移除 yarn 容器=============="
docker rm resourcemanager
docker rm nodemanager1
docker rm nodemanager2
docker rm nodemanager3
docker rm historyserver