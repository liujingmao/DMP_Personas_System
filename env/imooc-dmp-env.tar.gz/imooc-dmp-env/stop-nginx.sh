#!/bin/sh


echo "=========停止 nginx =============="
docker-compose stop nginx
echo "=========移除 nginx 容器=============="
docker rm nginx
