#!/bin/sh

docker cp check-init-mysql.sql mysql:/
docker exec -it mysql bash -c "mysql -uroot -p123456 < /check-init-mysql.sql"