#!/bin/sh

echo "=========停止 mysql =============="
docker-compose stop mysql
echo "=========移除 mysql 容器=============="
docker rm mysql