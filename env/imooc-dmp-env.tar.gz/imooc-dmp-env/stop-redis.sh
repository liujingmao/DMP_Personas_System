#!/bin/sh


echo "=========停止 redis =============="
docker-compose stop redis
echo "=========移除 redis 容器=============="
docker rm redis
