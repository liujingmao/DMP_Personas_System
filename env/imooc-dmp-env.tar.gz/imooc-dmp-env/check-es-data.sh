echo "=========ES 表数据==========="
docker cp ./load_tags_data/es_show_data.sh es:/usr/share/elasticsearch
docker exec -it es /bin/bash -c "sh es_show_data.sh"