SET NAMES 'utf8';
show databases;
use imooc;
show tables;
select * from tags limit 10;
select * from tags_type limit 10;
select * from crowds limit 10;
