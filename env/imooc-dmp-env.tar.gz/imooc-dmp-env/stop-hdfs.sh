#!/bin/sh


echo "=========停止 hdfs =============="
docker-compose stop namenode
docker-compose stop datanode1
docker-compose stop datanode2
docker-compose stop datanode3
echo "=========移除 hdfs 容器=============="
docker rm namenode
docker rm datanode1
docker rm datanode2
docker rm datanode3
source ./stop-yarn.sh