#!/bin/sh

echo "=========检查 clickhouse 启动状态=============="
docker-compose ps clickhouse