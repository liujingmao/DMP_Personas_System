#!/bin/sh


echo "=========启动 zookeeper =============="
docker-compose up -d zoo1
docker-compose up -d zoo2
docker-compose up -d zoo3

source ./check-zk.sh