#!/bin/sh


echo "=========停止 es =============="
docker-compose stop es 
echo "=========移除 es 容器=============="
docker rm es 
