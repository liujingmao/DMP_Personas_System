insert overwrite table dw.dws_user_action_tags_map_count_all
select 
`user_id`,`item_id`,
str_to_map(
	concat_ws(',',
		collect_list(
			concat_ws(':',cast(a.`type` as string),cast(a.`count` as string))
		)
	)
) as `tags`
from 
(
	select `user_id` ,`item_id` ,`type`,count(`type`)as `count` 
	from dw.fact_user_actions 
	group by `user_id`,`item_id`,`type`
) a
group by `user_id` ,`item_id`;
