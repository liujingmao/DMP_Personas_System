#!/bin/sh

curl -XPUT "http://127.0.0.1:9200/imooc?pretty" -d '
{
    "mappings" : {
        "tags":{
            "properties":{
                "user_id": {
                        "type": "keyword"
                },
                "user_tags": {
                    "type": "text",
                    "analyzer": "imooc_tags",
                    "search_analyzer": "whitespace"
                }
            }
        }
    },
    "settings" : {
        "analysis": {
            "analyzer": {
                "imooc_tags": {
                    "type": "pattern",
                    "pattern": "[|]"
                }
            }
        }
    }
}


'